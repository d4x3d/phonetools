import React, { useState, useCallback } from 'react';
import { Upload, Download, Filter, AlertCircle, CheckCircle, XCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { read, utils } from 'xlsx';
import Papa from 'papaparse';
import { phoneValidator } from '../lib/validator';
import type { PhoneValidationResult } from '../lib/types';

function NumberValidator() {
  const [numbers, setNumbers] = useState<PhoneValidationResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [expandedRows, setExpandedRows] = useState<Set<number>>(new Set());
  const [filters, setFilters] = useState({
    carrier: '',
    country: '',
    region: '',
    validOnly: false
  });
  const [singleNumber, setSingleNumber] = useState('');

  const showSuccess = (message: string) => {
    setSuccessMessage(message);
    setTimeout(() => setSuccessMessage(null), 3000);
  };

  const validateSingle = async () => {
    if (!singleNumber.trim()) {
      setError('Please enter a phone number');
      return;
    }

    try {
      const result = await phoneValidator.validateNumber(singleNumber.trim());
      setNumbers([result]);
      setSingleNumber('');
      showSuccess('Number validated successfully');
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Validation failed');
    }
  };

  const extractNumbersFromText = (text: string): string[] => {
    const patterns = [
      /\+\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,4}/g,
      /\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/g,
      /\d{3}[-.\s]?\d{3}[-.\s]?\d{4}/g,
      /\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,4}/g
    ];

    const matches = new Set<string>();
    patterns.forEach(pattern => {
      const found = text.match(pattern) || [];
      found.forEach(match => {
        matches.add(match.trim());
      });
    });

    return Array.from(matches);
  };

  const handleFileUpload = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    setError(null);
    setNumbers([]);

    try {
      const extension = file.name.split('.').pop()?.toLowerCase();
      let numbersToValidate: string[] = [];

      if (extension === 'xlsx' || extension === 'xls') {
        const data = await file.arrayBuffer();
        const workbook = read(data);
        const worksheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = utils.sheet_to_json<any>(worksheet);
        numbersToValidate = jsonData.flatMap(row => Object.values(row).map(String));
      } else if (extension === 'csv') {
        const text = await file.text();
        await new Promise<void>((resolve, reject) => {
          Papa.parse(text, {
            complete: (results) => {
              numbersToValidate = results.data.flat().map(String);
              resolve();
            },
            error: reject
          });
        });
      } else if (extension === 'txt') {
        const text = await file.text();
        numbersToValidate = extractNumbersFromText(text);
      } else {
        throw new Error('Unsupported file format. Please use XLSX, XLS, CSV, or TXT files.');
      }

      const validatedNumbers = await phoneValidator.validateBatch(
        numbersToValidate.filter(num => num && num.trim())
      );

      if (validatedNumbers.length === 0) {
        throw new Error('No valid phone numbers found in the file.');
      }

      setNumbers(validatedNumbers);
      showSuccess(`Successfully validated ${validatedNumbers.length} numbers`);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'An unexpected error occurred');
    } finally {
      setIsLoading(false);
      if (event.target) {
        event.target.value = '';
      }
    }
  }, []);

  const toggleRowExpansion = (index: number) => {
    const newExpanded = new Set(expandedRows);
    if (newExpanded.has(index)) {
      newExpanded.delete(index);
    } else {
      newExpanded.add(index);
    }
    setExpandedRows(newExpanded);
  };

  const filteredNumbers = numbers.filter(num => {
    if (filters.validOnly && !num.isValid) return false;
    if (filters.carrier && num.carrier !== filters.carrier) return false;
    if (filters.country && num.country !== filters.country) return false;
    if (filters.region && num.region !== filters.region) return false;
    return true;
  });

  const downloadResults = (filterType?: string) => {
    try {
      let numbersToDownload = filteredNumbers;
      let filename = 'validated_numbers';

      if (filterType) {
        const filterValue = filters[filterType as keyof typeof filters];
        if (filterValue) {
          numbersToDownload = filteredNumbers.filter(num => 
            num[filterType as keyof PhoneValidationResult] === filterValue
          );
          filename += `_${filterType}_${filterValue}`;
        }
      }

      const header = [
        'Original Number',
        'Valid',
        'Possible',
        'Formatted Number',
        'E164 Format',
        'National Format',
        'International Format',
        'RFC3966 Format',
        'Country',
        'Country Calling Code',
        'National Number',
        'Region',
        'Location',
        'Carrier',
        'Carrier Type',
        'Type',
        'Timezones'
      ].join(',');

      const content = numbersToDownload.map(num => [
        num.originalNumber,
        num.isValid,
        num.isPossible,
        num.formattedNumber || '',
        num.e164Format || '',
        num.nationalFormat || '',
        num.internationalFormat || '',
        num.rfc3966Format || '',
        num.country || '',
        num.countryCallingCode || '',
        num.nationalNumber || '',
        num.region || '',
        num.location || '',
        num.carrier || '',
        num.carrierInfo?.type || '',
        num.type || '',
        (num.timezone || []).join(';')
      ].join(','));

      const blob = new Blob([header + '\n' + content.join('\n')], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${filename}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showSuccess('Results downloaded successfully');
    } catch (error) {
      setError('Failed to download results');
    }
  };

  const uniqueValues = {
    carriers: [...new Set(numbers.map(n => n.carrier).filter(Boolean))],
    countries: [...new Set(numbers.map(n => n.country).filter(Boolean))],
    regions: [...new Set(numbers.map(n => n.region).filter(Boolean))]
  };

  return (
    <div className="bg-white rounded-lg shadow-xl p-6">
      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start">
          <AlertCircle className="w-5 h-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
          <p className="text-red-700">{error}</p>
        </div>
      )}

      {successMessage && (
        <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg">
          <p className="text-green-700">{successMessage}</p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4">Single Number Validation</h3>
          <div className="flex space-x-2">
            <input
              type="text"
              value={singleNumber}
              onChange={(e) => setSingleNumber(e.target.value)}
              placeholder="Enter phone number"
              className="flex-1 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
            />
            <button
              onClick={validateSingle}
              className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
            >
              Validate
            </button>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4">Batch Validation</h3>
          <label className={`flex flex-col items-center px-4 py-6 bg-indigo-50 text-indigo-600 rounded-lg border-2 border-dashed border-indigo-300 cursor-pointer hover:bg-indigo-100 transition-colors ${
            isLoading ? 'opacity-50 cursor-not-allowed' : ''
          }`}>
            <Upload className={`w-12 h-12 mb-2 ${isLoading ? 'animate-pulse' : ''}`} />
            <span className="text-sm font-medium">
              {isLoading ? 'Processing...' : 'Upload file (XLSX, CSV, TXT)'}
            </span>
            <span className="text-xs text-gray-500 mt-1">
              Drag and drop or click to select
            </span>
            <input
              type="file"
              className="hidden"
              accept=".xlsx,.xls,.csv,.txt"
              onChange={handleFileUpload}
              disabled={isLoading}
            />
          </label>
        </div>
      </div>

      {numbers.length > 0 && (
        <div>
          <div className="flex flex-wrap gap-4 mb-6">
            <div className="flex-1 min-w-[200px]">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Carrier
              </label>
              <select
                value={filters.carrier}
                onChange={(e) => setFilters({ ...filters, carrier: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="">All Carriers</option>
                {uniqueValues.carriers.map(carrier => (
                  <option key={carrier} value={carrier}>{carrier}</option>
                ))}
              </select>
            </div>
            <div className="flex-1 min-w-[200px]">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Country
              </label>
              <select
                value={filters.country}
                onChange={(e) => setFilters({ ...filters, country: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="">All Countries</option>
                {uniqueValues.countries.map(country => (
                  <option key={country} value={country}>{country}</option>
                ))}
              </select>
            </div>
            <div className="flex-1 min-w-[200px]">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Region
              </label>
              <select
                value={filters.region}
                onChange={(e) => setFilters({ ...filters, region: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="">All Regions</option>
                {uniqueValues.regions.map(region => (
                  <option key={region} value={region}>{region}</option>
                ))}
              </select>
            </div>
            <div className="flex items-end">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={filters.validOnly}
                  onChange={(e) => setFilters({ ...filters, validOnly: e.target.checked })}
                  className="h-4 w-4 text-indigo-600 rounded border-gray-300"
                />
                <span className="ml-2 text-sm text-gray-600">Valid numbers only</span>
              </label>
            </div>
          </div>

          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-700">
              Results ({filteredNumbers.length} numbers)
            </h2>
            <div className="flex space-x-2">
              <button
                onClick={() => downloadResults('carrier')}
                disabled={!filters.carrier}
                className="px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Download by Carrier
              </button>
              <button
                onClick={() => downloadResults('country')}
                disabled={!filters.country}
                className="px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Download by Country
              </button>
              <button
                onClick={() => downloadResults('region')}
                disabled={!filters.region}
                className="px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Download by Region
              </button>
              <button
                onClick={() => downloadResults()}
                className="px-3 py-1 bg-indigo-600 text-white text-sm rounded hover:bg-indigo-700 transition-colors"
              >
                Download All
              </button>
            </div>
          </div>

          <div className="border rounded-lg overflow-hidden">
            <div className="max-h-96 overflow-y-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="w-8 px-2 py-3"></th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Original Number</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Formatted Number</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Country</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Region</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Carrier</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredNumbers.map((number, index) => (
                    <React.Fragment key={index}>
                      <tr className={number.isValid ? 'bg-green-50' : 'bg-red-50'}>
                        <td className="px-2 py-4">
                          <button
                            onClick={() => toggleRowExpansion(index)}
                            className="text-gray-500 hover:text-gray-700"
                          >
                            {expandedRows.has(index) ? (
                              <ChevronUp className="w-4 h-4" />
                            ) : (
                              <ChevronDown className="w-4 h-4" />
                            )}
                          </button>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {number.isValid ? (
                            <CheckCircle className="w-5 h-5 text-green-500" />
                          ) : (
                            <XCircle className="w-5 h-5 text-red-500" />
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">{number.originalNumber}</td>
                        <td className="px-6 py-4 whitespace-nowrap">{number.formattedNumber || '-'}</td>
                        <td className="px-6 py-4 whitespace-nowrap">{number.country || '-'}</td>
                        <td className="px-6 py-4 whitespace-nowrap">{number.region || '-'}</td>
                        <td className="px-6 py-4 whitespace-nowrap">{number.carrier || '-'}</td>
                      </tr>
                      {expandedRows.has(index) && (
                        <tr className="bg-gray-50">
                          <td colSpan={7} className="px-6 py-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <h4 className="font-medium text-gray-700 mb-2">Formats</h4>
                                <p className="text-sm">E164: {number.e164Format || '-'}</p>
                                <p className="text-sm">National: {number.nationalFormat || '-'}</p>
                                <p className="text-sm">International: {number.internationalFormat || '-'}</p>
                                <p className="text-sm">RFC3966: {number.rfc3966Format || '-'}</p>
                              </div>
                              <div>
                                <h4 className="font-medium text-gray-700 mb-2">Additional Info</h4>
                                <p className="text-sm">Location: {number.location || '-'}</p>
                                <p className="text-sm">Type: {number.type || '-'}</p>
                                <p className="text-sm">Carrier Type: {number.carrierInfo?.type || '-'}</p>
                                <p className="text-sm">Possible: {number.isPossible ? 'Yes' : 'No'}</p>
                                <p className="text-sm">Timezones: {number.timezone?.join(', ') || '-'}</p>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default NumberValidator; 