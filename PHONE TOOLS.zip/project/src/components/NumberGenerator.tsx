import React, { useState, useRef, KeyboardEvent } from 'react';
import { Download, Plus, X, AlertCircle } from 'lucide-react';
import { getCountries, getCountryCallingCode, parsePhoneNumberFromString } from 'libphonenumber-js';

const countries = getCountries().map(country => ({
  code: country,
  name: new Intl.DisplayNames(['en'], { type: 'region' }).of(country) || country,
  dialCode: getCountryCallingCode(country)
}));

function NumberGenerator() {
  const [country, setCountry] = useState('US');
  const [areaCodes, setAreaCodes] = useState<string[]>([]);
  const [newAreaCode, setNewAreaCode] = useState('');
  const [quantity, setQuantity] = useState(100);
  const [generatedNumbers, setGeneratedNumbers] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const showSuccess = (message: string) => {
    setSuccessMessage(message);
    setTimeout(() => setSuccessMessage(null), 3000);
  };

  const validateAreaCode = (code: string): boolean => {
    if (!code) return false;
    const cleanCode = code.replace(/\D/g, '');
    if (cleanCode.length !== 3) return false;

    // Create a test number with the area code to validate
    const selectedCountry = countries.find(c => c.code === country);
    if (!selectedCountry) return false;

    const testNumber = `+${selectedCountry.dialCode}${cleanCode}5555555`;
    const parsed = parsePhoneNumberFromString(testNumber, country as any);
    return parsed?.isValid() || false;
  };

  const addAreaCode = () => {
    const cleanCode = newAreaCode.replace(/\D/g, '');
    if (!validateAreaCode(cleanCode)) {
      setError('Invalid area code. Please enter a valid 3-digit area code.');
      return;
    }

    if (areaCodes.includes(cleanCode)) {
      setError('Area code already added.');
      return;
    }

    setAreaCodes(prev => [...prev, cleanCode]);
    setNewAreaCode('');
    setError(null);
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const handleKeyPress = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && newAreaCode.trim()) {
      e.preventDefault();
      addAreaCode();
    }
  };

  const removeAreaCode = (index: number) => {
    setAreaCodes(prev => prev.filter((_, i) => i !== index));
  };

  const generateNumbers = async () => {
    try {
      setError(null);
      setIsGenerating(true);

      const selectedCountry = countries.find(c => c.code === country);
      if (!selectedCountry) {
        throw new Error('Invalid country selected');
      }

      const numbers: string[] = [];
      const codesForGeneration = areaCodes.length > 0 ? areaCodes : [''];

      for (const areaCode of codesForGeneration) {
        const prefix = `+${selectedCountry.dialCode}${areaCode}`;
        const remainingDigits = 10 - areaCode.length;

        for (let i = 0; i < quantity; i++) {
          let number;
          let isValid = false;
          
          while (!isValid) {
            number = prefix;
            for (let j = 0; j < remainingDigits; j++) {
              number += Math.floor(Math.random() * 10);
            }
            
            const parsed = parsePhoneNumberFromString(number, country as any);
            isValid = parsed?.isValid() || false;
          }
          
          numbers.push(number);
        }
      }

      setGeneratedNumbers(numbers);
      showSuccess(`Successfully generated ${numbers.length} valid numbers`);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'An unexpected error occurred');
    } finally {
      setIsGenerating(false);
    }
  };

  const downloadNumbers = () => {
    try {
      const blob = new Blob([generatedNumbers.join('\n')], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'generated_numbers.txt';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showSuccess('Numbers downloaded successfully');
    } catch (error) {
      setError('Failed to download numbers');
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-xl p-6">
      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start">
          <AlertCircle className="w-5 h-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
          <p className="text-red-700">{error}</p>
        </div>
      )}

      {successMessage && (
        <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg">
          <p className="text-green-700">{successMessage}</p>
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Country
          </label>
          <select
            value={country}
            onChange={(e) => setCountry(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
            disabled={isGenerating}
          >
            {countries.sort((a, b) => {
              if (a.code === 'US') return -1;
              if (b.code === 'US') return 1;
              return a.name.localeCompare(b.name);
            }).map((c) => (
              <option key={c.code} value={c.code}>
                {c.name} (+{c.dialCode})
              </option>
            ))}
          </select>
        </div>

        <div>
          <div className="flex justify-between items-center mb-2">
            <label className="block text-sm font-medium text-gray-700">
              Area Codes
            </label>
          </div>
          <div className="flex gap-2 mb-2">
            <input
              ref={inputRef}
              type="text"
              value={newAreaCode}
              onChange={(e) => setNewAreaCode(e.target.value.replace(/\D/g, '').slice(0, 3))}
              onKeyPress={handleKeyPress}
              className="flex-1 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="Enter area code and press Enter"
              maxLength={3}
              disabled={isGenerating}
            />
            <button
              onClick={addAreaCode}
              disabled={isGenerating || !newAreaCode}
              className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Add
            </button>
          </div>
          {areaCodes.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-2">
              {areaCodes.map((code, index) => (
                <div
                  key={index}
                  className="inline-flex items-center bg-indigo-100 text-indigo-800 rounded-full px-3 py-1"
                >
                  <span className="mr-1">{code}</span>
                  <button
                    onClick={() => removeAreaCode(index)}
                    className="text-indigo-600 hover:text-indigo-800"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
          <p className="text-sm text-gray-500">
            {areaCodes.length === 0 ? 
              "Leave empty to generate numbers without specific area codes" :
              `${areaCodes.length} area code${areaCodes.length > 1 ? 's' : ''} added`
            }
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Quantity (per area code)
          </label>
          <input
            type="number"
            value={quantity}
            onChange={(e) => setQuantity(Math.min(10000, Math.max(1, parseInt(e.target.value) || 0)))}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
            min="1"
            max="10000"
            disabled={isGenerating}
          />
          <p className="mt-1 text-sm text-gray-500">
            Total numbers to generate: {quantity * Math.max(1, areaCodes.length)}
          </p>
        </div>

        <button
          onClick={generateNumbers}
          disabled={isGenerating}
          className="w-full px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isGenerating ? 'Generating...' : 'Generate Numbers'}
        </button>
      </div>

      {generatedNumbers.length > 0 && (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-700">
              Generated Numbers ({generatedNumbers.length})
            </h2>
            <button
              onClick={downloadNumbers}
              disabled={isGenerating}
              className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Download className="w-4 h-4 mr-2" />
              Download
            </button>
          </div>

          <div className="border rounded-lg overflow-hidden">
            <div className="max-h-96 overflow-y-auto">
              {generatedNumbers.map((number, index) => (
                <div
                  key={index}
                  className={`px-4 py-2 ${
                    index !== generatedNumbers.length - 1 ? 'border-b' : ''
                  }`}
                >
                  {number}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default NumberGenerator;