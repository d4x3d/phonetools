import React, { useState, useCallback } from 'react';
import { Upload, Copy, Download, Trash2, AlertCircle, FileText } from 'lucide-react';
import { read, utils } from 'xlsx';
import Papa from 'papaparse';
import { extractPhoneNumbers, formatPhoneNumber } from '../utils/phoneUtils';

interface ExtractedNumber {
  value: string;
  originalFormat: string;
}

function NumberExtractor() {
  const [numbers, setNumbers] = useState<ExtractedNumber[]>([]);
  const [selectedNumbers, setSelectedNumbers] = useState<Set<string>>(new Set());
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [preserveFormat, setPreserveFormat] = useState(true);

  const showSuccess = (message: string) => {
    setSuccessMessage(message);
    setTimeout(() => setSuccessMessage(null), 3000);
  };

  const processContent = (content: string): ExtractedNumber[] => {
    return extractPhoneNumbers(content);
  };

  const handleFileUpload = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    setError(null);
    setNumbers([]);
    setSelectedNumbers(new Set());

    const extension = file.name.split('.').pop()?.toLowerCase();
    let extractedNumbers: ExtractedNumber[] = [];

    try {
      if (extension === 'xlsx' || extension === 'xls') {
        const data = await file.arrayBuffer();
        const workbook = read(data);
        const worksheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = utils.sheet_to_json<any>(worksheet);
        extractedNumbers = processContent(JSON.stringify(jsonData));
      } else if (extension === 'csv') {
        const text = await file.text();
        await new Promise<void>((resolve, reject) => {
          Papa.parse(text, {
            complete: (results) => {
              extractedNumbers = processContent(JSON.stringify(results.data));
              resolve();
            },
            error: reject
          });
        });
      } else if (extension === 'txt' || extension === 'json' || extension === 'md') {
        const text = await file.text();
        extractedNumbers = processContent(text);
      } else {
        throw new Error('Unsupported file format. Please use XLSX, CSV, TXT, JSON, or MD files.');
      }

      if (extractedNumbers.length === 0) {
        throw new Error('No valid phone numbers found in the file.');
      }

      setNumbers(extractedNumbers);
      showSuccess(`Successfully extracted ${extractedNumbers.length} numbers`);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'An unexpected error occurred');
    } finally {
      setIsLoading(false);
      if (event.target) {
        event.target.value = '';
      }
    }
  }, []);

  const copyToClipboard = async () => {
    try {
      const numbersToCopy = Array.from(selectedNumbers.size > 0 
        ? numbers.filter(n => selectedNumbers.has(n.value))
        : numbers);
      
      const textToCopy = numbersToCopy
        .map(n => preserveFormat ? n.originalFormat : formatPhoneNumber(n.value))
        .join('\n');
      
      await navigator.clipboard.writeText(textToCopy);
      showSuccess('Numbers copied to clipboard');
    } catch (error) {
      setError('Failed to copy numbers to clipboard');
    }
  };

  const downloadNumbers = () => {
    try {
      const numbersToDownload = Array.from(selectedNumbers.size > 0 
        ? numbers.filter(n => selectedNumbers.has(n.value))
        : numbers);
      
      const content = numbersToDownload
        .map(n => preserveFormat ? n.originalFormat : formatPhoneNumber(n.value))
        .join('\n');
      
      const blob = new Blob([content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'extracted_numbers.txt';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showSuccess('Numbers downloaded successfully');
    } catch (error) {
      setError('Failed to download numbers');
    }
  };

  const toggleNumber = (number: string) => {
    const newSelected = new Set(selectedNumbers);
    if (newSelected.has(number)) {
      newSelected.delete(number);
    } else {
      newSelected.add(number);
    }
    setSelectedNumbers(newSelected);
  };

  return (
    <div className="bg-white rounded-lg shadow-xl p-6">
      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start">
          <AlertCircle className="w-5 h-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
          <p className="text-red-700">{error}</p>
        </div>
      )}

      {successMessage && (
        <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg">
          <p className="text-green-700">{successMessage}</p>
        </div>
      )}

      <div className="mb-6">
        <label className={`flex flex-col items-center px-4 py-6 bg-indigo-50 text-indigo-600 rounded-lg border-2 border-dashed border-indigo-300 cursor-pointer hover:bg-indigo-100 transition-colors ${
          isLoading ? 'opacity-50 cursor-not-allowed' : ''
        }`}>
          <Upload className={`w-12 h-12 mb-2 ${isLoading ? 'animate-pulse' : ''}`} />
          <span className="text-sm font-medium">
            {isLoading ? 'Processing...' : 'Upload file (XLSX, CSV, TXT, JSON, MD)'}
          </span>
          <span className="text-xs text-gray-500 mt-1">
            Drag and drop or click to select
          </span>
          <input
            type="file"
            className="hidden"
            accept=".xlsx,.xls,.csv,.txt,.json,.md"
            onChange={handleFileUpload}
            disabled={isLoading}
          />
        </label>
      </div>

      {numbers.length > 0 && (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-700">
              Found {numbers.length} numbers
            </h2>
            <div className="flex items-center space-x-4">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={preserveFormat}
                  onChange={(e) => setPreserveFormat(e.target.checked)}
                  className="h-4 w-4 text-indigo-600 rounded border-gray-300 mr-2"
                />
                <span className="text-sm text-gray-600">Preserve original format</span>
              </label>
              <div className="space-x-2">
                <button
                  onClick={copyToClipboard}
                  disabled={isLoading}
                  className="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Copy className="w-4 h-4 mr-2" />
                  Copy {selectedNumbers.size > 0 ? 'Selected' : 'All'}
                </button>
                <button
                  onClick={downloadNumbers}
                  disabled={isLoading}
                  className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </button>
                <button
                  onClick={() => {
                    setNumbers([]);
                    setSelectedNumbers(new Set());
                  }}
                  disabled={isLoading}
                  className="inline-flex items-center px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Clear
                </button>
              </div>
            </div>
          </div>

          <div className="border rounded-lg overflow-hidden">
            <div className="max-h-96 overflow-y-auto">
              {numbers.map((number, index) => (
                <div
                  key={index}
                  className={`flex items-center px-4 py-2 hover:bg-gray-50 ${
                    index !== numbers.length - 1 ? 'border-b' : ''
                  } ${selectedNumbers.has(number.value) ? 'bg-indigo-50' : ''}`}
                >
                  <input
                    type="checkbox"
                    checked={selectedNumbers.has(number.value)}
                    onChange={() => toggleNumber(number.value)}
                    className="h-4 w-4 text-indigo-600 rounded border-gray-300"
                  />
                  <span className="ml-3 text-gray-700">
                    {preserveFormat ? number.originalFormat : formatPhoneNumber(number.value)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default NumberExtractor;