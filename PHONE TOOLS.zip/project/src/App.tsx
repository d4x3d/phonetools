import React, { useState } from 'react';
import { Phone, Hash, CheckCircle } from 'lucide-react';
import NumberExtractor from './components/NumberExtractor';
import NumberGenerator from './components/NumberGenerator';
import NumberValidator from './components/NumberValidator';

function App() {
  const [activeTab, setActiveTab] = useState<'extract' | 'generate' | 'validate'>('extract');

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <Phone className="h-8 w-8 text-indigo-600" />
                <span className="ml-2 text-xl font-bold text-gray-800">PhoneTools</span>
              </div>
              <div className="ml-6 flex space-x-8">
                <button
                  onClick={() => setActiveTab('extract')}
                  className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                    activeTab === 'extract'
                      ? 'border-indigo-500 text-gray-900'
                      : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                  }`}
                >
                  <Phone className="w-4 h-4 mr-2" />
                  Extract Numbers
                </button>
                <button
                  onClick={() => setActiveTab('generate')}
                  className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                    activeTab === 'generate'
                      ? 'border-indigo-500 text-gray-900'
                      : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                  }`}
                >
                  <Hash className="w-4 h-4 mr-2" />
                  Generate Numbers
                </button>
                <button
                  onClick={() => setActiveTab('validate')}
                  className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                    activeTab === 'validate'
                      ? 'border-indigo-500 text-gray-900'
                      : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                  }`}
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Validate Numbers
                </button>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'extract' && <NumberExtractor />}
        {activeTab === 'generate' && <NumberGenerator />}
        {activeTab === 'validate' && <NumberValidator />}
      </main>
    </div>
  );
}

export default App;