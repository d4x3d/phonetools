import { describe, it, expect, beforeEach } from 'vitest';
import { PhoneValidator } from './validator';
import { ValidationOptions } from './types';

describe('PhoneValidator', () => {
  let validator: PhoneValidator;

  beforeEach(() => {
    validator = PhoneValidator.getInstance();
  });

  it('should validate a correct US phone number', async () => {
    const result = await validator.validateNumber('+1234567890');
    expect(result.isValid).toBe(true);
    expect(result.country).toBe('US');
  });

  it('should invalidate an incorrect phone number', async () => {
    const result = await validator.validateNumber('invalid');
    expect(result.isValid).toBe(false);
  });

  it('should handle batch validation', async () => {
    const numbers = ['+1234567890', 'invalid', '+44123456789'];
    const results = await validator.validateBatch(numbers);
    expect(results).toHaveLength(3);
    expect(results[0].isValid).toBe(true);
    expect(results[1].isValid).toBe(false);
    expect(results[2].isValid).toBe(true);
  });

  it('should respect country code in options', async () => {
    const options: ValidationOptions = { country: 'GB' };
    const result = await validator.validateNumber('07700900000', options);
    expect(result.isValid).toBe(true);
    expect(result.country).toBe('GB');
  });
});