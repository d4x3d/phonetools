import {
  parsePhoneNumber,
  CountryCode,
  PhoneNumber
} from 'libphonenumber-js';
import { phone } from 'phone';
import { geocoder, carrier as carrierLookup, timezones } from 'libphonenumber-geo-carrier';
import { PhoneNumberToCarrierMapper } from 'phone-carrier';
import { PhoneValidationResult, ValidationOptions } from './types';
import { validationCache } from './cache';
import { rateLimiter } from './rateLimit';

export class PhoneValidator {
  private static instance: PhoneValidator;
  private carrierMapper: typeof PhoneNumberToCarrierMapper;
  
  private constructor() {
    this.carrierMapper = PhoneNumberToCarrierMapper.getInstance();
  }

  static getInstance(): PhoneValidator {
    if (!PhoneValidator.instance) {
      PhoneValidator.instance = new PhoneValidator();
    }
    return PhoneValidator.instance;
  }

  async validateNumber(
    phoneNumber: string,
    options: ValidationOptions = {}
  ): Promise<PhoneValidationResult> {
    const cacheKey = `${phoneNumber}-${JSON.stringify(options)}`;
    const cachedResult = validationCache.get(cacheKey);
    if (cachedResult) return cachedResult;

    if (!rateLimiter.isAllowed('default')) {
      throw new Error('Rate limit exceeded. Please try again later.');
    }

    try {
      const result = phone(phoneNumber, { country: options.country });
      const parsedNumber = parsePhoneNumber(phoneNumber, options.country);

      if (!result.isValid || !parsedNumber) {
        return {
          isValid: false,
          originalNumber: phoneNumber
        };
      }

      let location = 'Unknown';
      let carrierInfo = undefined;
      let timezoneInfo = undefined;

      try {
        location = await geocoder(parsedNumber) || 'Unknown';
        const carrier1 = await carrierLookup(parsedNumber);
        const carrier2 = await this.carrierMapper.getNameForValidNumber(phoneNumber);
        carrierInfo = {
          name: carrier2 || carrier1 || 'Unknown',
          type: parsedNumber.getType() || 'Unknown'
        };
        timezoneInfo = await timezones(parsedNumber);
      } catch (error) {
        console.error('Error fetching additional info:', error);
      }

      const validationResult: PhoneValidationResult = {
        isValid: true,
        originalNumber: phoneNumber,
        formattedNumber: result.phoneNumber,
        country: result.countryIso2 as CountryCode,
        carrier: carrierInfo?.name,
        region: parsedNumber.getRegionCode() || 'Unknown',
        type: parsedNumber.getType(),
        timezone: timezoneInfo,
        e164Format: parsedNumber.format('E.164'),
        nationalFormat: parsedNumber.formatNational(),
        internationalFormat: parsedNumber.formatInternational(),
        rfc3966Format: parsedNumber.format('RFC3966'),
        countryCallingCode: parsedNumber.countryCallingCode,
        nationalNumber: parsedNumber.nationalNumber,
        isPossible: parsedNumber.isPossible(),
        location: location,
        carrierInfo
      };

      validationCache.set(cacheKey, validationResult);
      return validationResult;
    } catch (error) {
      throw new Error(`Validation failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async validateBatch(
    phoneNumbers: string[],
    options: ValidationOptions = {}
  ): Promise<PhoneValidationResult[]> {
    const results: PhoneValidationResult[] = [];
    const batchSize = 10;
    
    for (let i = 0; i < phoneNumbers.length; i += batchSize) {
      const batch = phoneNumbers.slice(i, i + batchSize);
      const batchResults = await Promise.all(
        batch.map(number => this.validateNumber(number, options))
      );
      results.push(...batchResults);
    }

    return results;
  }
}
 
export const phoneValidator = PhoneValidator.getInstance();