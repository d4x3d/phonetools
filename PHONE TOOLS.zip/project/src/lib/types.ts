import { CountryCode } from 'libphonenumber-js'; 

export interface PhoneValidationResult {
  isValid: boolean;
  originalNumber: string;
  formattedNumber?: string;
  country?: CountryCode;
  carrier?: string;
  region?: string;
  type?: string;
  timezone?: string[];
  e164Format?: string;
  nationalFormat?: string;
  internationalFormat?: string;
  rfc3966Format?: string;
  countryCallingCode?: string;
  nationalNumber?: string;
  isPossible?: boolean;
  location?: string;
  carrierInfo?: {
    name?: string;
    type?: string;
    mobileCountryCode?: string;
    mobileNetworkCode?: string;
  };
}

export interface ValidationOptions {
  country?: CountryCode;
  validateCarrier?: boolean;
  validateRegion?: boolean;
  validateTimezone?: boolean;
}

export interface CacheConfig {
  enabled: boolean;
  ttl: number;
  maxSize: number;
}

export interface RateLimitConfig {
  maxRequests: number;
  windowMs: number;
}