import { parsePhoneNumberFromString, CountryCode } from 'libphonenumber-js';

interface ExtractedNumber {
  value: string;
  originalFormat: string;
}

export const extractPhoneNumbers = (text: string): ExtractedNumber[] => {
  // Match various phone number formats including international
  const patterns = [
    // International format with + prefix
    /\+\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,4}/g,
    // Numbers with parentheses for area code
    /\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/g,
    // Basic 10-digit format
    /\d{3}[-.\s]?\d{3}[-.\s]?\d{4}/g,
    // International without + prefix
    /\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,4}/g
  ];

  const matches = new Set<string>();
  const results: ExtractedNumber[] = [];

  patterns.forEach(pattern => {
    const found = text.match(pattern) || [];
    found.forEach(match => {
      const cleaned = match.trim();
      if (!matches.has(cleaned)) {
        matches.add(cleaned);
        results.push({
          value: cleaned,
          originalFormat: match
        });
      }
    });
  });

  // Filter valid numbers and preserve original format
  return results.filter(({ value }) => {
    const parsed = parsePhoneNumberFromString(value);
    return parsed?.isValid() || false;
  });
};

export const formatPhoneNumber = (number: string, countryCode?: CountryCode): string => {
  const parsed = parsePhoneNumberFromString(number, countryCode);
  return parsed?.format('INTERNATIONAL') || number;
};